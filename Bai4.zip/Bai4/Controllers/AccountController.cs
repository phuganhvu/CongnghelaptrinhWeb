using Bai4.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bai4.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Account model)
        {
            if (model.Username == "admin" && model.Password == "123")
            {
                ViewBag.Message = "Đăng nhập thành công!";
            }
            else
            {
                ViewBag.Message = "Sai tên đăng nhập hoặc mật khẩu!";
            }

            return View(model);
        }
    }
}
